package com.clock.exception;

@SuppressWarnings("serial")
public class InvalidTimeException extends RuntimeException {

	public InvalidTimeException(String message) {
		super(message);
	}

}
