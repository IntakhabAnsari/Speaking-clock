package com.clock.unit;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.clock.exception.InvalidTimeException;
import com.clock.service.TimeConverter;

public class TimeConverterTest {
    private TimeConverter timeConverter;

    @BeforeEach
    public void setUp() {
        timeConverter = new TimeConverter();
    }

    @Test
    public void testConvertTimeToWords_ValidTime_ReturnsConvertedTime() {
        String time = "08:34";
        String expected = "It's eight thirty-four";
        String convertedTime = timeConverter.convertTimeToWords(time);
        Assertions.assertEquals(expected, convertedTime);
    }

    @Test
    public void testConvertTimeToWords_InvalidTime_ThrowsException() {
        String time = "25:00";
        Assertions.assertThrows(InvalidTimeException.class, () -> {
            timeConverter.convertTimeToWords(time);
        });
    }
}
