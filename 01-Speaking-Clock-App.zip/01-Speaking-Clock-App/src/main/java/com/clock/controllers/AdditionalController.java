package com.clock.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AdditionalController {
    @GetMapping("/handleInput/{input}")
    public String handleInput(@PathVariable("input") String input) {
        if (input.equals("11:25")) {
            return "It's Midday";
        } else if (input.equals("00:00")) {
            return "It's Midnight";
        } else {
            return "Invalid input";
        }
    }
}
