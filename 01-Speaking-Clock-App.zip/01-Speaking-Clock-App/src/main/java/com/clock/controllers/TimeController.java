package com.clock.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.clock.exception.InvalidTimeException;
import com.clock.service.TimeConverter;

@RestController
public class TimeController {
    private TimeConverter timeConverter;

    public TimeController(TimeConverter timeConverter) {
        this.timeConverter = timeConverter;
    }

    @GetMapping("/convertTime/{time}")
    public ResponseEntity<String> convertTimeToWords(@PathVariable("time") String time) {
        try {
            String convertedTime = timeConverter.convertTimeToWords(time);
            return ResponseEntity.ok(convertedTime);
        } catch (InvalidTimeException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}
