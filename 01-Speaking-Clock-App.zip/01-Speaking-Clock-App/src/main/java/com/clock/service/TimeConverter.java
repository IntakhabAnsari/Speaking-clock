package com.clock.service;

import org.springframework.stereotype.Service;

import com.clock.exception.InvalidTimeException;

@Service
public class TimeConverter {
    private static final String[] HOURS = {
        "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
        "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
        "twenty", "twenty-one", "twenty-two", "twenty-three"
    };

    private static final String[] MINUTES = {
        "o' clock", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine",
        "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
        "twenty", "twenty-one", "twenty-two", "twenty-three", "twenty-four", "twenty-five", "twenty-six", "twenty-seven", "twenty-eight", "twenty-nine",
        "thirty", "thirty-one", "thirty-two", "thirty-three", "thirty-four", "thirty-five", "thirty-six", "thirty-seven", "thirty-eight", "thirty-nine",
        "forty", "forty-one", "forty-two", "forty-three", "forty-four", "forty-five", "forty-six", "forty-seven", "forty-eight", "forty-nine",
        "fifty", "fifty-one", "fifty-two", "fifty-three", "fifty-four", "fifty-five", "fifty-six", "fifty-seven", "fifty-eight", "fifty-nine"
    };

    public String convertTimeToWords(String time) {
        try {
            String[] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);
            int minutes = Integer.parseInt(parts[1]);

            if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
                String hourInWords = HOURS[hours];
                String minuteInWords = MINUTES[minutes];

                if (minutes == 0) {
                    return "It's " + hourInWords + " o' clock";
                } else if (minutes == 15) {
                    return "It's quarter past " + hourInWords;
                } else if (minutes == 30) {
                    return "It's half past " + hourInWords;
                } else if (minutes == 45) {
                    int nextHour = (hours + 1) % 24;
                    String nextHourInWords = HOURS[nextHour];
                    return "It's quarter to " + nextHourInWords;
                } else if (minutes < 30) {
                    return "It's " + minuteInWords + " minutes past " + hourInWords;
                } else {
                    int nextHour = (hours + 1) % 24;
                    String nextHourInWords = HOURS[nextHour];
                    return "It's " + minuteInWords + " minutes to " + nextHourInWords;
                }
            } else {
                throw new InvalidTimeException("Invalid time format: " + time);
            }
        } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
            throw new InvalidTimeException("Invalid time format: " + time);
        }
    }
}
